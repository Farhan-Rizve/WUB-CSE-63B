#include <stdio.h>

int main()
{
    //variable
    int a, b;
    //user input
    printf("Enter Number of A : ");
    scanf("%d", &a);
    printf("Enter Number of b : ");
    scanf("%d", &b);

    /* Print results of a & b variable arithmetic
    operation. */
    printf("\nSum of addition : %d \n", a+b);

    printf("Sum of subtraction : %d \n", a-b);

    printf("Sum of multiplication : %d \n", a*b);

    printf("Sum of divison : %d \n", a/b);

    return 0;
}



