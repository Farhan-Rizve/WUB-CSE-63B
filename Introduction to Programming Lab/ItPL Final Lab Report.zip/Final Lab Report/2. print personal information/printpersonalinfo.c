#include <stdio.h>

int main()
{
    // Print your name, date of brith & mobile number
    printf("Name \t\t : \t Md. Farhan Tanvir Rizve \n");

    printf("Date of Brith \t : \t 23th January 2001 \n");

    printf("Mobile Number \t : \t +8801872787012 \n");

    return 0;
}

