#include <stdio.h>

int main()
{
    //variable
    int a = 2, b = 6;

    /* Print results of a & b variable arithmetic
    operation. */
    printf("Sum of addition : %d \n", a+b);

    printf("Sum of subtraction : %d \n", b-a);

    printf("Sum of multiplication : %d \n", a*b);

    printf("Sum of divison : %d \n", b/a);

    return 0;
}
