#include <stdio.h>

int main()
{
    // Print university name
    printf("World University Bangladesh");

    return 0;
}
